package org.splevo.tests.statements;

public class VariableDeclarationStatements {

    public void doSth(){
        String var1, var3 = "Hello";
    }
    
}
