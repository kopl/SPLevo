/**
 * Package with code to test statement changes.
 */
package org.splevo.tests.statements;