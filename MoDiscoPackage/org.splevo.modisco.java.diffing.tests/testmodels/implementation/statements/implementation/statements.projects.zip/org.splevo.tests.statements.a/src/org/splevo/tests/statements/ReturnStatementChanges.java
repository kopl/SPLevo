package org.splevo.tests.statements;

public class ReturnStatementChanges {

    public void doSth(String a){
        
        return;
    }
    
    public void noReturn(){
        
    }
    
    public String returnWithExpression(){
        return "Hello";
    }
    
    public String returnWithExpressionEqual(){
        return "Good Morning";
    }
    
}
