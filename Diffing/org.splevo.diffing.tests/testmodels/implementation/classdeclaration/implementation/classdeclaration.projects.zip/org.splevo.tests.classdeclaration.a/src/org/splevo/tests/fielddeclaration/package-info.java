/**
 * Class declaration diffing test code.
 * @author Benjamin Klatt
 */
package org.splevo.tests.fielddeclaration;