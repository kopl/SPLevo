package org.splevo.tests.fielddeclaration.newpackage.sub;

public class NewSubPackageClass {

}
