package org.splevo.tests.fielddeclaration;

public class AddedClassDeclaration {

    public void doSth(){
        
    }
}
