/**
 * An added package.
 */
package org.splevo.tests.fielddeclaration.newpackage;