package org.splevo.tests.fielddeclaration;

public class EnumClass {

    public enum EnumChange {
        A,
        NEW,
        B
    }
    
}
