/**
 * An added sub package.
 */
package org.splevo.tests.fielddeclaration.newpackage.sub;