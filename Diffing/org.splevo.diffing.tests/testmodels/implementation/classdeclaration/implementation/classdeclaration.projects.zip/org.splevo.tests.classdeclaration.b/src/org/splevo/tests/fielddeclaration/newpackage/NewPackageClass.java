package org.splevo.tests.fielddeclaration.newpackage;

public class NewPackageClass {

}
