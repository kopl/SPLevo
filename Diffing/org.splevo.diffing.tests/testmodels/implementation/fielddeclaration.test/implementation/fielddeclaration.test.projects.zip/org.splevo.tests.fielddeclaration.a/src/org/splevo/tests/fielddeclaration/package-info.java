/**
 * Test classes to test the diffing of Fielddeclarations
 */
package org.splevo.tests.fielddeclaration;