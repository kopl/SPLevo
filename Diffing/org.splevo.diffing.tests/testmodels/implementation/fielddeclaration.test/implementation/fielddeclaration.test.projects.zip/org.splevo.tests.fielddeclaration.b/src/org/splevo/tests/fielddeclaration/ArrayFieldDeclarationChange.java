package org.splevo.tests.fielddeclaration;

public class ArrayFieldDeclarationChange {

    public Object[] newValueArray = new Object[]{
            "value1",
            "valueInTheMiddle",
            "value2"
    };
    
}
