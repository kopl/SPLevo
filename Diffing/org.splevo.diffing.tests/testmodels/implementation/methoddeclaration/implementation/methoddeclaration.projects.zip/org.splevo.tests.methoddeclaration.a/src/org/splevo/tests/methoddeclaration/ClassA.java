package org.splevo.tests.methoddeclaration;

public class ClassA {

}
