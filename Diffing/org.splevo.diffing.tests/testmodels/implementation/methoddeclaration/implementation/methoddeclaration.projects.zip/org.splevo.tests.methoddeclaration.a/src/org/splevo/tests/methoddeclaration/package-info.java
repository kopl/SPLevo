/**
 * Package with test code for diffing unit tests.
 */
package org.splevo.tests.methoddeclaration;