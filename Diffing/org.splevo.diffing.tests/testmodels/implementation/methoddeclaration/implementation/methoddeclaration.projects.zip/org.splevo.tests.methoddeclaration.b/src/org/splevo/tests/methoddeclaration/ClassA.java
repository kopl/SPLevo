package org.splevo.tests.methoddeclaration;

public class ClassA {
    
    public void newMethod(){
        System.out.println("a");
    }

}