package org.splevo.tests.statements;

public class ClassStatementInsert {

    public void newStatement(){
        
        System.out.println(new Integer(0));
        
        System.out.println(new Double(0));
        
    }
    
}
