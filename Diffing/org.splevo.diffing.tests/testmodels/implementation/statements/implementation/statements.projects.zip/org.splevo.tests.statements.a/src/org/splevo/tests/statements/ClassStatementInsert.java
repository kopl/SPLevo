package org.splevo.tests.statements;

public class ClassStatementInsert {

    public void newStatement(){
        
        System.out.println(new Integer(0));
        
        System.out.println(new Double(0));
        
        Boolean f = null;
        f = super.equals(new Object());
        
        int i = 0;
        int j = Integer.valueOf("0") + (i++);
    }
    
}
