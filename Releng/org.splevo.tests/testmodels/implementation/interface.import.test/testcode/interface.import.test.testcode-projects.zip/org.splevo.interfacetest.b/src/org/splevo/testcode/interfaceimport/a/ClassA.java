package org.splevo.testcode.interfaceimport.a;

import java.io.Serializable;

public class ClassA implements Serializable {
    
    /** */
    private static final long serialVersionUID = 8357053675825335420L;

    public void myMethod(){
        // do nothing.
    }

}
