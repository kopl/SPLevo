package org.splevo.testcode.interfaceimport.a;

public class ClassA {
    
    public void myMethod(){
        // do nothing.
    }

}
