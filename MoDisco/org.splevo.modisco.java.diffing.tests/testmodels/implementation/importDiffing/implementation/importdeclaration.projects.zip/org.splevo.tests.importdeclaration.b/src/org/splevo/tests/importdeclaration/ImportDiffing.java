package org.splevo.tests.importdeclaration;

import java.math.BigDecimal;

public class ImportDiffing {

    public void helloWorld(){
        
    }
}
