package org.splevo.tests.importdeclaration;

import java.math.BigInteger;

public class ImportDiffing {

    public void helloWorld(){
        
    }
}
