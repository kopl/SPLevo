package org.splevo.test.variabledeclaration;

import java.math.BigInteger;

public class A {

    public void methodA() {
        BigInteger integerValue1 = new BigInteger("1");
    }

}
