package org.splevo.test.variabledeclaration;

import java.math.BigDecimal;

public class A {

    public void methodA() {
        BigDecimal integerValue1 = new BigDecimal("1");
    }

}
