package org.splevo.modisco.java.diffing.tests.access;

import java.util.ArrayList;
import java.util.List;
import javax.xml.xpath.XPath;

public class TypeParameter {

    class EventAndListeners {
        public EventAndListeners(String a, String b) {
        }
    }

	public TypeParameter() {
		List<EventAndListeners> events = new ArrayList<EventAndListeners>();
		System.out.println(events);
	}
	
	public void arrayParameterMethod(XPath[] extents){
	    System.out.println(extents);
	}
	
	/**
	 * An unresolveable reference in a java doc comment tag that is not changed.
	 * 
	 * @see org.netbeans.lib.jmi.xmi.XmiContext#XmiContext(javax.xml.xpath.XPath[], org.netbeans.api.xmi.XMIInputConfig)
	 */
	public void textReference(){
	    
	}

}
