/**
 * 
 */
/**
 * @author benjamin
 *
 */
package org.splevo.modisco.java.diffing.tests.access;