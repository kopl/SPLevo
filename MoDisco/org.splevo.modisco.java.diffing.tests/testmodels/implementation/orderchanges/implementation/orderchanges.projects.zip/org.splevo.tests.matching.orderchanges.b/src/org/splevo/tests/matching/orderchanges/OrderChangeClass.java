package org.splevo.tests.matching.orderchanges;

import java.math.BigInteger;
import java.math.BigDecimal;

public class OrderChangeClass {

    public static final BigInteger CONST2 = null;
    public static final BigInteger CONST1 = null;

    private String field2 = "field2";
    private String field3 = "field3";
    private String field1 = "field1";

    public BigDecimal method2(){
        return null;
    }
    
    public void method1(){
        
    }
}
