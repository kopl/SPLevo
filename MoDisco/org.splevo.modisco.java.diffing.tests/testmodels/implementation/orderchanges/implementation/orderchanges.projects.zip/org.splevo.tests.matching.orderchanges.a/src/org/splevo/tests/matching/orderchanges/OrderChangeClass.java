package org.splevo.tests.matching.orderchanges;

import java.math.BigDecimal;
import java.math.BigInteger;

public class OrderChangeClass {

    public static final BigInteger CONST1 = null;
    public static final BigInteger CONST2 = null;
    
    private String field1 = "field1";
    private String field2 = "field2";
    private String field3 = "field3";
    
    public void method1(){
        
    }

    public BigDecimal method2(){
        return null;
    }
}
